using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ComputershareCodingTest;

namespace ComputershareUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodReadFileCorrect()
        {
            string fileName = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.FullName + @"\ComputershareCodingtest\Data\ChallengeSampleDataSet1.txt";
            double firstItem = 18.93;
            List<Double> valsReturned = new List<Double>();

            valsReturned = ComputershareCodingTest.Program.returnFileData(fileName);
            Assert.AreEqual(valsReturned[0], firstItem);



        }

        [TestMethod]
        public void TestMethodReadIncorrect()
        {
            string fileName = @"kjdhfkjhdkfjg.txt";
            List<Double> valsReturned = new List<Double>();

            valsReturned = ComputershareCodingTest.Program.returnFileData(fileName);
            Assert.AreEqual(valsReturned[0], -1.00);
        }

        [TestMethod]
        public void TestMethodOneValuePerDataSet()
        {
            List<Double> dataSetOne = new List<Double>();
            dataSetOne.Add(13.30);


            string valueExpected = "1(13.3),1(13.3)";

            string actual = ComputershareCodingTest.Program.returnBestBuyAndSellDays(dataSetOne);
            Assert.AreEqual(valueExpected, actual);

        }

        [TestMethod]
        public void TestMethodBothMultiValue()
        {
            List<Double> dataSetOne = new List<Double>();

            dataSetOne.Add(13.30);
            dataSetOne.Add(7.63);
            dataSetOne.Add(25.56);
            dataSetOne.Add(24.32);
            dataSetOne.Add(14.32);

            string valueExpected = "2(7.63),3(25.56)";

            string actual = ComputershareCodingTest.Program.returnBestBuyAndSellDays(dataSetOne);
            Assert.AreEqual(valueExpected, actual);

        }

    }
}
