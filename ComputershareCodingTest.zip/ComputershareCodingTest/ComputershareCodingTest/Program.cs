﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ComputershareCodingTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<Double> sharePricesData = new List<Double>();
            string sharePriceDataFile1 = Directory.GetCurrentDirectory() + @"\Data\ChallengeSampleDataSet1.txt";
            string sharePriceDataFile2 = Directory.GetCurrentDirectory() + @"\Data\ChallengeSampleDataSet2.txt";
            string bestDayToBuyAndSell = "";

            
            sharePricesData = returnFileData(sharePriceDataFile1);

            if (sharePricesData[0] == -1.00) {
                Console.WriteLine("File Data For one or both files was not complete");
            }

            bestDayToBuyAndSell = returnBestBuyAndSellDays(sharePricesData);

            Console.WriteLine("Best Day to buy in file 1 is \n");
            Console.WriteLine(bestDayToBuyAndSell + "\n");

            sharePricesData = returnFileData(sharePriceDataFile2);

            if (sharePricesData[0] == -1.00)
            {
                Console.WriteLine("File Data For one or both files was not complete");
            }

            bestDayToBuyAndSell = returnBestBuyAndSellDays(sharePricesData);

            Console.WriteLine("Best Day to buy in file 2 is \n");
            Console.WriteLine(bestDayToBuyAndSell);
        
        }




        public static List<Double> returnFileData (string fileName){

            List<Double> csvData = new List<Double>();

            try {
                    
                string fileData = File.ReadAllText(fileName);
                string[] commaSeparatedData = fileData.Split(',');
                
                foreach (string dataPoint in commaSeparatedData)
                {
                    csvData.Add(Double.Parse(dataPoint));
                }

            } catch (FileNotFoundException ex){
                Console.WriteLine(ex);
                csvData.Add(-1.00);
            }


            return csvData;
        }

        public static string returnBestBuyAndSellDays(List<Double> shareData) {

            string bestBuyAndSellDay = "";
            double bestBuyDayPrice = shareData[0];
            double bestSellDayPrice = shareData[0];
            int bestBuyDay = 0;
            int bestSellDay = 0;
            double bestDifference = shareData[bestSellDay] - shareData[bestBuyDay];

            if (shareData.Count == 1)
            {
                bestBuyDay = 1;
                bestBuyDayPrice = shareData[0];
                bestSellDay = 1;
                bestSellDayPrice = shareData[0];

                

            } else {

                for (int i = 0; i < shareData.Count; i++)
                {
                    for (int j = 0; j < shareData.Count; j++)
                    {

                        if ((shareData[j] - shareData[i]) > bestDifference)
                        {
                            if (j + 1 >= bestBuyDay)
                            {
                                bestSellDay = j + 1;
                                bestSellDayPrice = shareData[j];
                                bestDifference = bestSellDayPrice - bestBuyDayPrice;
                            }
                        }

                        if ((shareData[j] - shareData[i]) > bestDifference)
                        {
                            if(i + 1 <= bestSellDay)
                            {
                                bestBuyDay = i + 1;
                                bestBuyDayPrice = shareData[i];
                                bestDifference = bestSellDayPrice - bestBuyDayPrice;
                            }
                        }
                    }

                }
            }

          
            bestBuyAndSellDay = bestBuyDay.ToString() + "(" + bestBuyDayPrice.ToString() + ")" + "," + bestSellDay.ToString() + "(" + shareData[bestSellDay - 1].ToString() + ")";

            return bestBuyAndSellDay;
        }

    }
}
